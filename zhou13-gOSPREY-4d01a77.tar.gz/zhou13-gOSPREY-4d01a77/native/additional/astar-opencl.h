#pragma once

#include "astar.h"

void init_opencl(void);
int *astar_opencl(bool first_run);
