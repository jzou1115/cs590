#pragma once

#include "astar.h"

void init_cpu();
int *astar_cpu(bool first_run);
