
//MH: I AM REDACTING THIS CLASS FOR THE COMETS RELEASE

public class MSMPLP {
	
	
	MSMPLP(int aNumResidues, int aNumRotForRes[], ReducedEnergyMatrix aPairwiseMinEnergyMatrix){
		throw new RuntimeException("ERROR: CLASS MSMPLP NOT READY FOR RELEASE");
        }
        
        
	public double optimizeEMPLP(int partialConf[], int iterations){
                throw new RuntimeException("ERROR: CLASS MSMPLP NOT READY FOR RELEASE");
	}
}
